#DONOT COPY FROM ANY OTHER STUDENT, AI BASED CHECK WILL APPLY IF FLAG RAISED THEN CONSIDERED AS BAD PRACTICE.
# design are given in design folder
![screen shot](./design/desktop-design.jpg "screen shot")

# mobile ui
![screen shot](./design/mobile-design.jpg "screen shot")

